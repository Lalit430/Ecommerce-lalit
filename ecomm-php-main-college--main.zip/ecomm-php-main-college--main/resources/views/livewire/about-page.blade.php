<div class="py-32  p-10    sm:py-16">

    <div class="px-6 mx-auto shadow bg-white dark:bg-gray-800 max-w-[1720px] lg:px-8">
        <div class="max-w-2xl mx-auto pt-10 sm:text-center">
            <h2 class="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-5xl">About Us</h2>
            <p class="mt-6 text-lg leading-8 text-gray-700 dark:text-gray-300">GTechMaria is Gadgets & Accessories based shop where various
                kind of brand Apple,Xiaomi,Samsung gadgets available </p>
        </div>
        <div class="max-w-3xl mx-auto mt-16 rounded-3xl ring-1 ring-gray-200 dark:ring-gray-700 sm:mt-20 lg:mx-0 lg:flex lg:justify-center lg:max-w-[1580px]">
            <div class="p-8 sm:p-10 lg:flex-auto lg:justify-center">
              
                {{-- <div class="p-3 bg-gray-200">
            <img src="img/photo.png" alt="">
          </div> --}}
          <section class="mt-6 text-base leading-7 text-gray-600 dark:text-gray-300">
            <p>
              <strong>GTechMaria</strong> is more than just a gadget store—it's a haven for tech enthusiasts and casual shoppers alike. 
              As a one-stop destination for cutting-edge gadgets and accessories, GTechMaria proudly features renowned global brands like 
              <strong>Apple</strong>, <strong>Xiaomi</strong>, and <strong>Samsung</strong>, ensuring you have access to the latest and most trusted products in the market.
            </p>
          
            <h2 class="mt-8 text-lg font-semibold text-gray-800 dark:text-white">What Sets Us Apart?</h2>
            <ul class="list-disc pl-6 mt-4 space-y-2">
              <li>
                <strong>Wide Range of Products:</strong> From smartphones, tablets, and smartwatches to accessories like earbuds, chargers, 
                cases, and more, GTechMaria covers every tech need under one roof.
              </li>
              <li>
                <strong>Competitive Pricing:</strong> We believe in delivering value for money, offering premium products at prices 
                that suit your budget. Look out for exclusive deals and discounts!
              </li>
              <li>
                <strong>Personalized Recommendations:</strong> Unsure about which gadget to choose? Our knowledgeable team is here to provide 
                tailored advice, ensuring you make the right purchase based on your needs and preferences.
              </li>
              <li>
                <strong>Secure Transactions:</strong> At GTechMaria, your privacy and security are our top priorities. Our secure payment 
                systems ensure every transaction is smooth and hassle-free.
              </li>
              <li>
                <strong>Sustainable Practices:</strong> We care about the environment and strive to promote sustainable practices by offering 
                eco-friendly packaging and supporting gadgets designed with sustainability in mind.
              </li>
              <li>
                <strong>Convenient Location:</strong> Located in <strong>Tokha near Ganesthan</strong>, GTechMaria is easily accessible for 
                residents and visitors alike. Whether you're local or just passing through, we are here to serve your tech needs.
              </li>
            </ul>
          
            <h2 class="mt-8 text-lg font-semibold text-gray-800 dark:text-white">Our Vision for Expansion</h2>
            <p class="mt-4">
              GTechMaria is committed to becoming a household name in Nepal's tech landscape. With plans to expand to 
              <strong>Ason</strong>, <strong>Sitapaila</strong>, <strong>Pulchowk</strong>, <strong>Balkot</strong>, and other locations, 
              we aim to bring our exceptional services closer to more communities.
            </p>
          
            <h2 class="mt-8 text-lg font-semibold text-gray-800">A Shopping Experience Like No Other</h2>
            <p class="mt-4">
              At GTechMaria, we don’t just sell gadgets—we create an immersive shopping experience. From a warm welcome at the store 
              to after-sales support, we ensure that every customer leaves satisfied and eager to return.
            </p>
          
            <h2 class="mt-8 text-lg font-semibold text-gray-800">Follow Us</h2>
            <p class="mt-4">
              Stay updated on the latest arrivals, offers, and store updates through our social media platforms and website. Be part 
              of our growing tech community and never miss out on what's new!
            </p>
          </section>
          
   
          <section class="bg-white dark:bg-gray-900 py-12">
            <div class="container mx-auto px-6 lg:px-16">
                
                <!-- Location Heading -->
                <h3 class="text-2xl font-bold tracking-tight text-gray-900 dark:text-white pb-6 ">Location</h3>
        
                <!-- Smaller Map with More Gap Below -->
                <div id="map" class="w-full h-[390px] shadow-md rounded-lg mb-12"></div>
        
                <!-- Contact Form - Smaller Size & Centered -->
                <div class="w-full max-w-4xl mx-auto  bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
                    
                    @if (session()->has('success'))
                    <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 5000)" x-show="show"
                         class="bg-green-200 text-green-800 px-4 py-2 rounded-lg mb-4 transition-opacity duration-500 ease-out">
                        {{ session('success') }}
                    </div>
                @endif
                
                @if (session()->has('error'))
                    <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 5000)" x-show="show"
                         class="bg-red-800 text-white px-4 py-2 rounded-lg mb-4 transition-opacity duration-500 ease-out">
                        {{ session('error') }}
                    </div>
                @endif
                
        
                    <h2 class="mb-3 text-2xl font-extrabold text-center text-gray-900 dark:text-white">Contact Us</h2>
                    <p class="mb-6 text-center  text-gray-500 dark:text-gray-400 sm:text-base">
                        Got a technical issue? Need support? Let us know.
                    </p>
        
                    <form wire:submit='send' method="post" class="space-y-5">
                        <div>
                            <label for="name" class="block mb-1 text-sm font-medium text-gray-900 dark:text-gray-300">
                                Your Name
                            </label>
                            <input type="text" id="name" wire:model='name'
                                class="w-full p-2 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                placeholder="Your Name">
                            @error('name') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                        </div>
        
                        <div>
                            <label for="email" class="block mb-1 text-sm font-medium text-gray-900 dark:text-gray-300">
                                Your Email
                            </label>
                            <input type="email" id="email" wire:model='email'
                                class="w-full p-2 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                placeholder="example@gmail.com">
                            @error('email') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                        </div>
        
                        <div>
                            <label for="message" class="block mb-1 text-sm font-medium text-gray-900 dark:text-gray-400">
                                Your Message
                            </label>
                            <textarea id="message" wire:model='message' rows="4"
                                class="w-full p-2 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                placeholder="Write your message here..."></textarea>
                            @error('message') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                        </div>
        
                        <button type="submit"
                            class="py-2 px-4 text-sm text-white bg-orange-500 rounded-lg hover:bg-orange-600 focus:ring-4 focus:outline-none dark:bg-orange-600 dark:hover:bg-orange-700">
                            Send Message
                        </button>
                    </form>
                </div>
        
            </div>
        </section>
        
        {{-- <section class="bg-white dark:bg-gray-900 py-12">
            <div class="container mx-auto px-6 lg:px-16">
                <h3 class="text-3xl font-bold tracking-tight text-gray-900 pb-8  ">Location</h3>
                
                <!-- Flex Container -->
                <div class="flex flex-col lg:flex-row items-center lg:items-start gap-12">
                    
                    <!-- Map Section -->
                    <div id="map" class="w-full lg:w-1/2 h-[550px] shadow-md mt-4 rounded-lg"></div>
        
                    <!-- Contact Form -->
                    <div class="w-full lg:w-1/2 bg-white dark:bg-gray-800 p-8 rounded-lg shadow-2xl">
                        
                        @if (session()->has('success'))
                            <div class="bg-green-200 text-green-800 px-4 py-2 rounded-lg mb-4">
                                {{ session('success') }}
                            </div>
                        @endif
                        @if (session()->has('error'))
                            <div class="bg-red-800 text-white px-4 py-2 rounded-lg mb-4">
                                {{ session('error') }}
                            </div>
                        @endif
        
                        <h2 class="mb-4 text-3xl font-extrabold text-center text-gray-900 dark:text-white">Contact Us</h2>
                        <p class="mb-8 text-center text-gray-500 dark:text-gray-400 sm:text-lg">
                            Got a technical issue? Need support? Let us know.
                        </p>
        
                        <form wire:submit='send' method="post" class="space-y-6">
                            <div>
                                <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    Your Name
                                </label>
                                <input type="text" id="name" wire:model='name'
                                    class="w-full p-2.5 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                    placeholder="Your Name">
                                @error('name') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                            </div>
        
                            <div>
                                <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    Your Email
                                </label>
                                <input type="email" id="email" wire:model='email'
                                    class="w-full p-2.5 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                    placeholder="example@gmail.com">
                                @error('email') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                            </div>
        
                            <div>
                                <label for="message" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-400">
                                    Your Message
                                </label>
                                <textarea id="message" wire:model='message' rows="5"
                                    class="w-full p-2.5 text-sm bg-gray-50 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                                    placeholder="Write your message here..."></textarea>
                                @error('message') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                            </div>
        
                            <button type="submit"
                                class="py-3 px-5 text-sm text-white bg-orange-500 rounded-lg hover:bg-orange-600 focus:ring-4 focus:outline-none dark:bg-orange-600 dark:hover:bg-orange-700">
                                Send Message
                            </button>
                        </form>
                    </div>
        
                </div>
            </div>
        </section> 
         --}}








            </div>





        </div>
    </div>
</div>

<script>
    function myMap() {
        // var mapCanvas=document.getElementById('map');
        var mylatlng = {
            lat: 27.76880577299551,
            lng: 85.33039015233905
        }
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: mylatlng,
        })
        new google.maps.Marker({
            position: mylatlng,
            map,
        });

        // var mapOptions={ 

        //   center: new google.maps.LatLng(27.76880577299551,85.33039015233905),
        //   zoom:10
        // };
        // var map=new google.maps.Map(mapCanvas,mapOptions);

    }
</script>
<script src="https://maps.gomaps.pro/maps/api/js?key=AlzaSynuqVU-MSW6mzlj_W_sYZFbgRmeV3_d6Od&callback=myMap" async
    defer></script>
