<header
    class="sticky top-0 z-[1000] flex flex-wrap w-full py-3 text-sm bg-white shadow-xl md:justify-start md:flex-nowrap md:py-0 dark:bg-gray-800">
    <nav class="max-w-[85rem] w-full mx-auto px-4 md:px-6 py-2 lg:px-8" aria-label="Global">
        <div class="relative md:flex md:items-center md:justify-between">
            <div class="flex items-center justify-between p-4">
                <!-- Brand Name -->
                <a class="flex-none text-center text-4xl font-bold text-black dark:text-white" wire:navigate
                    href="/" aria-label="Brand">GTechMaria</a>

                <!-- Hamburger Icon (Visible on small screens) -->
                <button wire:click="toggleMenus"
                    class="p-3 text-white md:hidden bg-gray-800 rounded-md focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                        stroke-width="2" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>

                <!-- Mobile Menu (Visible when menuOpen is true) -->
                <div class="md:hidden fixed inset-0 bg-gray-800 text-white z-30 transition-all duration-300 ease-in-out"
                    @if ($menuOpen) style="transform: translateX(0);" @else style="transform: translateX(100%);" @endif>

                    <!-- Close (Cross) Button -->
                    <div class="flex justify-between items-center p-4">
                        <button wire:click="toggleMenus" class="text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor" stroke-width="2" class="w-8 h-8">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>

                    <!-- Menu Items -->
                    <div class="flex flex-col items-center py-6 ">
                        <div class="flex space-x-1 text-gray-500 text-5xl justify-end">
                            <a wire:navigate
                                class="font-semibold flex gap-1   {{ request()->is('/') ? 'text-orange-400' : 'text-gray-500' }}  text-blue-600 py-3 md:py-8 dark:text-gray-300 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-900  "
                                href="/" aria-current="page">
                                <span class="dark:text-gray-900"><svg xmlns="http://www.w3.org/2000/svg" height="60px" width="40px"
                                        viewBox="0 -960 960 960"  fill="#434343">
                                        <path
                                            d="M226.67-186.67h140v-246.66h226.66v246.66h140v-380L480-756.67l-253.33 190v380ZM160-120v-480l320-240 320 240v480H526.67v-246.67h-93.34V-120H160Zm320-352Z" />
                                    </svg></span>
                                <p>Home</p>
                            </a>

                        </div>
                        <div class="flex space-x-1 text-gray-500 text-5xl">


                            <a wire:navigate
                                class=" flex font-semibold {{ request()->is('categories') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-900"
                                href="/categories">
                                <span
                                    class="py-5 {{ request()->is('categories') ? 'text-orange-400' : 'text-gray-500' }} "><svg
                                        xmlns="http://www.w3.org/2000/svg"  viewBox="0 -960 960 960"
                                        height="60px" width="40px" fill="7F8C8D">
                                        <path
                                            d="m261-526 220-354 220 354H261ZM706-80q-74 0-124-50t-50-124q0-74 50-124t124-50q74 0 124 50t50 124q0 74-50 124T706-80Zm-586-25v-304h304v304H120Zm586.08-35Q754-140 787-173.08q33-33.09 33-81Q820-302 786.92-335q-33.09-33-81-33Q658-368 625-334.92q-33 33.09-33 81Q592-206 625.08-173q33.09 33 81 33ZM180-165h184v-184H180v184Zm189-421h224L481-767 369-586Zm112 0ZM364-349Zm342 95Z" />
                                    </svg></span>
                                <p class="py-5 ">Categories</p>

                            </a>
                        </div>
                        <div class="flex space-x-1 text-gray-500 text-5xl">

                          <a wire:navigate
                              class=" flex font-semibold {{ request()->is('products') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                              href="/products">
                              <span
                                  class="py-5 {{ request()->is('products') ? 'text-orange-400' : 'text-gray-500' }}"><img
                                     height="60px" width="40px"
                                      src="https://img.icons8.com/windows/32/product.png" alt="product" /></span>
                              <p class="py-5">Products</p>
                          </a>
                      </div>


                      <a wire:navigate
                          class="font-semibold flex items-center text-5xl {{ request()->is('cart') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                          href="/cart">
                          <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 -960 960 960"
                          height="60px" width="40px" fill="#434343">
                              <path
                                  d="M284.53-80.67q-30.86 0-52.7-21.97Q210-124.62 210-155.47q0-30.86 21.98-52.7Q253.95-230 284.81-230t52.69 21.98q21.83 21.97 21.83 52.83t-21.97 52.69q-21.98 21.83-52.83 21.83Zm400 0q-30.86 0-52.7-21.97Q610-124.62 610-155.47q0-30.86 21.98-52.7Q653.95-230 684.81-230t52.69 21.98q21.83 21.97 21.83 52.83t-21.97 52.69q-21.98 21.83-52.83 21.83ZM238.67-734 344-515.33h285.33l120-218.67H238.67ZM206-800.67h589.38q22.98 0 34.97 20.84 11.98 20.83.32 41.83L693.33-490.67q-11 19.34-28.87 30.67-17.87 11.33-39.13 11.33H324l-52 96h487.33V-286H278q-43 0-63-31.83-20-31.84-.33-68.17l60.66-111.33-149.33-316H47.33V-880h121.34L206-800.67Zm138 285.34h285.33H344Z" />
                          </svg>
                          <span class="mr-1">Cart</span> <sup
                              class="py-[2px] px-[5px] rounded-full text-base font-medium bg-white border border-orange-200 text-orange-600">{{ $total_count }}</sup>
                      </a>

                    <div class="text-5xl text-gray-500 dark:text-gray-300 mb-10 mt-8 dark:hover:text-gray-500">
                      <button type="button" @click="isDarkMode=!isDarkMode">
                        <span class="text-white" x-show="isDarkMode"> <svg stroke="currentColor"
                                fill="currentColor" stroke-width="0" viewBox="0 0 16 16" height="30"
                                width="30" xmlns="http://www.w3.org/2000/svg">
                                <path d="M11.473 11a4.5 4.5 0 0 0-8.72-.99A3 3 0 0 0 3 16h8.5a2.5 2.5 0 0 0 0-5z">
                                </path>
                                <path
                                    d="M10.5 1.5a.5.5 0 0 0-1 0v1a.5.5 0 0 0 1 0zm3.743 1.964a.5.5 0 1 0-.707-.707l-.708.707a.5.5 0 0 0 .708.708zm-7.779-.707a.5.5 0 0 0-.707.707l.707.708a.5.5 0 1 0 .708-.708zm1.734 3.374a2 2 0 1 1 3.296 2.198q.3.423.516.898a3 3 0 1 0-4.84-3.225q.529.017 1.028.129m4.484 4.074c.6.215 1.125.59 1.522 1.072a.5.5 0 0 0 .039-.742l-.707-.707a.5.5 0 0 0-.854.377M14.5 6.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1z">
                                </path>
                            </svg>
                            <path d="M11.473 11a4.5 4.5 0 0 0-8.72-.99A3 3 0 0 0 3 16h8.5a2.5 2.5 0 0 0 0-5z">
                            </path>
                            <path
                                d="M10.5 1.5a.5.5 0 0 0-1 0v1a.5.5 0 0 0 1 0zm3.743 1.964a.5.5 0 1 0-.707-.707l-.708.707a.5.5 0 0 0 .708.708zm-7.779-.707a.5.5 0 0 0-.707.707l.707.708a.5.5 0 1 0 .708-.708zm1.734 3.374a2 2 0 1 1 3.296 2.198q.3.423.516.898a3 3 0 1 0-4.84-3.225q.529.017 1.028.129m4.484 4.074c.6.215 1.125.59 1.522 1.072a.5.5 0 0 0 .039-.742l-.707-.707a.5.5 0 0 0-.854.377M14.5 6.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1z">
                            </path></svg>
                        </span></span>
                        <span class="font-bold text-3xl" x-show="!isDarkMode"> <svg stroke="currentColor"
                                fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round"
                                stroke-linejoin="round" height="30" width="30"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="5"></circle>
                                <line x1="12" y1="1" x2="12" y2="3"></line>
                                <line x1="12" y1="21" x2="12" y2="23"></line>
                                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                <line x1="1" y1="12" x2="3" y2="12"></line>
                                <line x1="21" y1="12" x2="23" y2="12"></line>
                                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                            </svg>
                            <circle cx="12" cy="12" r="5"></circle>
                            <line x1="12" y1="1" x2="12" y2="3"></line>
                            <line x1="12" y1="21" x2="12" y2="23"></line>
                            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                            <line x1="1" y1="12" x2="3" y2="12"></line>
                            <line x1="21" y1="12" x2="23" y2="12"></line>
                            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>

                    </button> <span >Mode</span>
                    </div>
                     <div class="">
                




                    @guest
                    <div class="pt-3 md:pt-0">
                        <a wire:navigate
                            class="py-2.5 px-4 inline-flex items-center gap-x-2 text-semibold font-semibold rounded-lg border border-transparent bg-orange-600 text-white hover:bg-orange-500 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                            href="/login">
                            <svg class="flex-shrink-0 w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="32"
                                height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                                <circle cx="12" cy="7" r="4" />
                            </svg>
                            Log in
                        </a>
                    </div>
                @endguest
                
                
                @auth
                    <div class="flex items-center gap-2 md:mx-0">
                        <!-- User's name without extra padding or margin -->
                        <div class="text-gray-600  dark:text-gray-300 font-semibold text-5xl">
                            {{ auth()->user()->name }}
                        </div>
                
                        <!-- User Profile Dropdown -->
                        <div class="relative">
                            <!-- User image and menu button -->
                            <button wire:click="toggleMenu"
                                class="relative flex text-sm bg-gray-800 rounded-full focus:outline-none focus:ring-4 focus:ring-blue-200 focus:ring-offset-1 focus:ring-offset-gray-800">
                                <img class="rounded-full h-8 w-8 object-cover"
                                    src="{{ asset('storage/' . auth()->user()->image) }}" alt="User Image">
                            </button>
                
                            <!-- Dropdown Menu -->
                            <div class="absolute right-0 z-10 w-48 py-1 mt-2 origin-top-right border-gray-300 border bg-white rounded-md shadow-lg ring-4 ring-black ring-opacity-5 focus:outline-none 
                                @if ($open) block @else hidden @endif" id="user-menu" role="menu" 
                                aria-orientation="vertical" aria-labelledby="user-menu-button"
                                tabindex="-1">
                
                                <!-- Menu items -->
                                <div class="py-2">
                                    <!-- Profile Link -->
                                    <a wire:navigate href="{{ route('userinfo.show') }}"
                                        class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                        role="menuitem" tabindex="-1" id="user-menu-item-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                            viewBox="0 0 24 24" stroke-width="1.5"
                                            stroke="currentColor" class="w-5 h-5 mr-3">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                                        </svg>
                                        <p>My Profile</p>
                                    </a>
                
                                    <!-- Orders Link -->
                                    <a wire:navigate href="/my-orders"
                                        class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                        role="menuitem" tabindex="-1" id="user-menu-item-0">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                            height="20" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="w-5 h-5 mr-3">
                                            <path
                                                d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z">
                                            </path>
                                            <line x1="3" y1="6" x2="21"
                                                y2="6"></line>
                                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                                        </svg>
                                        <p>My Orders</p>
                                    </a>
                
                                    <!-- Logout Link -->
                                    <a wire:navigate href="/logout"
                                        class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                        role="menuitem" tabindex="-1" id="user-menu-item-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20"
                                            height="20" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="w-5 h-5 mr-3">
                                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                            <polyline points="16 17 21 12 16 7"></polyline>
                                            <line x1="21" y1="12" x2="9"
                                                y2="12"></line>
                                        </svg>
                                        <p>Sign out</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endauth
                     </div>
                

                      
                    </div>
                </div>

                
              </div>
              
              
              
              
              
              <!-- Menu for larger screens (md and up) -->
            <div id="navbar-collapse-with-animation"
                class="hidden overflow-hidden transition-all duration-300 hs-collapse basis-full grow md:block"
               >
                <div class="overflow-hidden overflow-y-auto max-h-[75vh]  ">
                    <div
                        class="flex flex-col md:space-y-0  space-y-4 text-xl mt-2    divide-gray-200 gap-x-0 d md:flex-row md:items-center md:justify-end md:gap-x-7 md:mt-0 md:ps-7 md:divide-y-0 md:divide-solid dark:divide-gray-900">

                        <div class="flex space-x-1 text-gray-500">
                            <a wire:navigate
                                class="font-semibold flex gap-1   {{ request()->is('/') ? 'text-orange-400' : 'text-gray-500' }}  text-blue-600 py-3 md:py-8 dark:text-gray-300 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-900  "
                                href="/" aria-current="page">
                                <span class="dark:text-gray-900"><svg xmlns="http://www.w3.org/2000/svg" height="32px"
                                        viewBox="0 -960 960 960" width="32px" fill="#434343">
                                        <path
                                            d="M226.67-186.67h140v-246.66h226.66v246.66h140v-380L480-756.67l-253.33 190v380ZM160-120v-480l320-240 320 240v480H526.67v-246.67h-93.34V-120H160Zm320-352Z" />
                                    </svg></span>
                                <p>Home</p>
                            </a>

                        </div>




                        <div class="flex space-x-1 text-gray-500">


                            <a wire:navigate
                                class=" flex font-semibold {{ request()->is('categories') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-900"
                                href="/categories">
                                <span
                                    class="py-5 {{ request()->is('categories') ? 'text-orange-400' : 'text-gray-500' }} "><svg
                                        xmlns="http://www.w3.org/2000/svg" height="32px" viewBox="0 -960 960 960"
                                        width="32px" fill="7F8C8D">
                                        <path
                                            d="m261-526 220-354 220 354H261ZM706-80q-74 0-124-50t-50-124q0-74 50-124t124-50q74 0 124 50t50 124q0 74-50 124T706-80Zm-586-25v-304h304v304H120Zm586.08-35Q754-140 787-173.08q33-33.09 33-81Q820-302 786.92-335q-33.09-33-81-33Q658-368 625-334.92q-33 33.09-33 81Q592-206 625.08-173q33.09 33 81 33ZM180-165h184v-184H180v184Zm189-421h224L481-767 369-586Zm112 0ZM364-349Zm342 95Z" />
                                    </svg></span>
                                <p class="py-5 ">Categories</p>

                            </a>
                        </div>

                        <div class="flex space-x-1 text-gray-500">

                            <a wire:navigate
                                class=" flex font-semibold {{ request()->is('products') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                                href="/products">
                                <span
                                    class="py-5 {{ request()->is('products') ? 'text-orange-400' : 'text-gray-500' }}"><img
                                        width="32" height="32"
                                        src="https://img.icons8.com/windows/32/product.png" alt="product" /></span>
                                <p class="py-5">Products</p>
                            </a>
                        </div>


                        <a wire:navigate
                            class="font-semibold flex items-center {{ request()->is('cart') ? 'text-orange-400' : 'text-gray-500' }} hover:text-gray-400 py-3 md:py-6 dark:text-gray-300 dark:hover:text-gray-500 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                            href="/cart">
                            <svg xmlns="http://www.w3.org/2000/svg" height="32px" viewBox="0 -960 960 960"
                                width="32px" fill="#434343">
                                <path
                                    d="M284.53-80.67q-30.86 0-52.7-21.97Q210-124.62 210-155.47q0-30.86 21.98-52.7Q253.95-230 284.81-230t52.69 21.98q21.83 21.97 21.83 52.83t-21.97 52.69q-21.98 21.83-52.83 21.83Zm400 0q-30.86 0-52.7-21.97Q610-124.62 610-155.47q0-30.86 21.98-52.7Q653.95-230 684.81-230t52.69 21.98q21.83 21.97 21.83 52.83t-21.97 52.69q-21.98 21.83-52.83 21.83ZM238.67-734 344-515.33h285.33l120-218.67H238.67ZM206-800.67h589.38q22.98 0 34.97 20.84 11.98 20.83.32 41.83L693.33-490.67q-11 19.34-28.87 30.67-17.87 11.33-39.13 11.33H324l-52 96h487.33V-286H278q-43 0-63-31.83-20-31.84-.33-68.17l60.66-111.33-149.33-316H47.33V-880h121.34L206-800.67Zm138 285.34h285.33H344Z" />
                            </svg>
                            <span class="mr-1">Cart</span> <sup
                                class="py-[2px] px-[5px] rounded-full text-base font-medium bg-white border border-orange-200 text-orange-600">{{ $total_count }}</sup>
                        </a>

                        <button type="button" @click="isDarkMode=!isDarkMode">
                            <span class="text-white" x-show="isDarkMode"> <svg stroke="currentColor"
                                    fill="currentColor" stroke-width="0" viewBox="0 0 16 16" height="30"
                                    width="30" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M11.473 11a4.5 4.5 0 0 0-8.72-.99A3 3 0 0 0 3 16h8.5a2.5 2.5 0 0 0 0-5z">
                                    </path>
                                    <path
                                        d="M10.5 1.5a.5.5 0 0 0-1 0v1a.5.5 0 0 0 1 0zm3.743 1.964a.5.5 0 1 0-.707-.707l-.708.707a.5.5 0 0 0 .708.708zm-7.779-.707a.5.5 0 0 0-.707.707l.707.708a.5.5 0 1 0 .708-.708zm1.734 3.374a2 2 0 1 1 3.296 2.198q.3.423.516.898a3 3 0 1 0-4.84-3.225q.529.017 1.028.129m4.484 4.074c.6.215 1.125.59 1.522 1.072a.5.5 0 0 0 .039-.742l-.707-.707a.5.5 0 0 0-.854.377M14.5 6.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1z">
                                    </path>
                                </svg>
                                <path d="M11.473 11a4.5 4.5 0 0 0-8.72-.99A3 3 0 0 0 3 16h8.5a2.5 2.5 0 0 0 0-5z">
                                </path>
                                <path
                                    d="M10.5 1.5a.5.5 0 0 0-1 0v1a.5.5 0 0 0 1 0zm3.743 1.964a.5.5 0 1 0-.707-.707l-.708.707a.5.5 0 0 0 .708.708zm-7.779-.707a.5.5 0 0 0-.707.707l.707.708a.5.5 0 1 0 .708-.708zm1.734 3.374a2 2 0 1 1 3.296 2.198q.3.423.516.898a3 3 0 1 0-4.84-3.225q.529.017 1.028.129m4.484 4.074c.6.215 1.125.59 1.522 1.072a.5.5 0 0 0 .039-.742l-.707-.707a.5.5 0 0 0-.854.377M14.5 6.5a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1z">
                                </path></svg>
                            </span></span>
                            <span class="font-bold text-3xl" x-show="!isDarkMode"> <svg stroke="currentColor"
                                    fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round"
                                    stroke-linejoin="round" height="30" width="30"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="12" cy="12" r="5"></circle>
                                    <line x1="12" y1="1" x2="12" y2="3"></line>
                                    <line x1="12" y1="21" x2="12" y2="23"></line>
                                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                    <line x1="1" y1="12" x2="3" y2="12"></line>
                                    <line x1="21" y1="12" x2="23" y2="12"></line>
                                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                                </svg>
                                <circle cx="12" cy="12" r="5"></circle>
                                <line x1="12" y1="1" x2="12" y2="3"></line>
                                <line x1="12" y1="21" x2="12" y2="23"></line>
                                <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                <line x1="1" y1="12" x2="3" y2="12"></line>
                                <line x1="21" y1="12" x2="23" y2="12"></line>
                                <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>

                        </button>

                        @guest
                            <div class="pt-3 md:pt-0">
                                <a wire:navigate
                                    class="py-2.5 px-4 inline-flex items-center gap-x-2 text-semibold font-semibold rounded-lg border border-transparent bg-orange-600 text-white hover:bg-orange-500 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                                    href="/login">
                                    <svg class="flex-shrink-0 w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="32"
                                        height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                                        <circle cx="12" cy="7" r="4" />
                                    </svg>
                                    Log in
                                </a>
                            </div>

                        @endguest


                        @auth



                            <div class="flex gap-2 ">
                                <div class="text-gray-600 dark:text-gray-300 font-semibold  text-xl md:mx-0 ">
                                    {{ auth()->user()->name }}
                                    {{-- {{ dd(auth()->user()->image) }} --}}


                                </div>
                                <div class="md:mx-0 ">
                                    <button type="button"
                                        class="relative flex right-1 text-sm bg-gray-800 rounded-full focus:outline-none focus:ring-4 focus:ring-blue-200 focus:ring-offset-1 focus:ring-offset-gray-800"
                                        id="user-menu-button" aria-expanded="false" aria-haspopup="true">
                                        <span class="absolute -inset-1"></span>
                                        <span class="sr-only">Open user menu</span>
                                        <div class="flex items-center">

                                            <!-- User Menu (Dropdown) -->
                                            <div class="relative" wire:click.away="closeMenu">

                                                <!-- Button to toggle the menu -->
                                                <button wire:click="toggleMenu"
                                                    class="flex text-sm bg-gray-800 rounded-full">
                                                    <img class="rounded-full h-8 w-8 object-cover"
                                                        src="{{ asset('storage/' . auth()->user()->image) }}"
                                                        alt="User Image">
                                                </button>

                                                <!-- Dropdown Menu -->
                                                <div class="absolute right-0 z-10 w-48 py-1 mt-2 origin-top-right border-gray-300 border bg-white rounded-md shadow-lg ring-4 ring-black ring-opacity-5 focus:outline-none 
            @if ($open) block @else hidden @endif"
                                                    id="user-menu" role="menu" 
                                                    aria-orientation="vertical" aria-labelledby="user-menu-button"
                                                    tabindex="-1">

                                                    <!-- Menu items -->
                                                    <div class="py-2">
                                                        <!-- Profile Link -->
                                                        <a wire:navigate href="{{ route('userinfo.show') }}"
                                                            class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                                            role="menuitem" tabindex="-1" id="user-menu-item-1">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                viewBox="0 0 24 24" stroke-width="1.5"
                                                                stroke="currentColor" class="w-5 h-5 mr-3">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                                                            </svg>
                                                            <p>My Profile</p>
                                                        </a>

                                                        <!-- Orders Link -->
                                                        <a wire:navigate href="/my-orders"
                                                            class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                                            role="menuitem" tabindex="-1" id="user-menu-item-0">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                                                height="20" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2"
                                                                stroke-linecap="round" stroke-linejoin="round"
                                                                class="w-5 h-5 mr-3">
                                                                <path
                                                                    d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z">
                                                                </path>
                                                                <line x1="3" y1="6" x2="21"
                                                                    y2="6"></line>
                                                                <path d="M16 10a4 4 0 0 1-8 0"></path>
                                                            </svg>
                                                            <p>My Orders</p>
                                                        </a>

                                                        <!-- Logout Link -->
                                                        <a wire:navigate href="/logout"
                                                            class="flex items-center px-4 py-2 text-base font-semibold text-gray-700 hover:bg-gray-100 rounded-md"
                                                            role="menuitem" tabindex="-1" id="user-menu-item-2">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="20"
                                                                height="20" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2"
                                                                stroke-linecap="round" stroke-linejoin="round"
                                                                class="w-5 h-5 mr-3">
                                                                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                                                <polyline points="16 17 21 12 16 7"></polyline>
                                                                <line x1="21" y1="12" x2="9"
                                                                    y2="12"></line>
                                                            </svg>
                                                            <p>Sign out</p>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>






                                        </div>


                                </div>






                            </div>















                        @endauth


                    </div>
                </div>
            </div>
        </div>
    </nav>




</header>
