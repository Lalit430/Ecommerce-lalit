<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile Form</title>
  {{-- <link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.3.2/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script> --}}
  <style>
    /* Ensure the image preview fits nicely */
    .profile-preview {
      width: 200px;
      height: 200px;
      object-fit: cover;
      border-radius: 40%;
    }
  </style>
</head>
<body class="bg-gray-50 dark:bg-slate-800 dark:text-white">
  {{-- action="{{ route('userinfo.update', auth()->user()->id) }}" --}}
  <div class="max-w-4xl p-6 mx-auto bg-white rounded-lg shadow-md dark:bg-slate-800 dark:text-white">
  
    <form class="space-y-12 "     >
     
      {{-- wire:submit.prevent="update"  --}}
      {{-- action="route({{ 'userinfo.update' }})" --}}
    
      {{-- wire:submit.prevent="save({{ $userInfo->id }})" --}}
      
     
      {{-- @foreach($userInfo as $user)
        {{ $user->name }} --}}
     
  
      <!-- Profile Section -->
      <div class="pb-12 border-b border-gray-300 dark:bg-slate-800 dark:text-white">
        <h2 class="text-2xl font-semibold text-gray-900 dark:bg-slate-800 dark:text-white">Profile</h2>
        <p class="mt-1 text-gray-600">This information will be displayed publicly, so be careful what you share.</p>


             <!-- Photo -->
             <div class="col-span-full">
                <label for="photo" class="block text-sm font-medium text-gray-900">Profile Photo 
               
            
            </label> 
                <div class="flex items-center mt-2 gap-x-3">
                  <div class="relative">
                    <img id="photo-preview" src="{{  asset('storage/' . auth()->user()->image) }}" 
         alt="Profile Preview" class="profile-preview">
                    <input type="file" id="photo-preview"  wire:model="file" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer" onchange="previewPhoto(event)"  >
                    

                  {{-- <button type="button" class="inline-flex items-center dark:bg-slate-800 dark:text-white px-3 py-1.5 text-sm font-semibold text-gray-900 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50" >Change</button> --}}
                </div>
                </div>
              </div>


              <div class="grid grid-cols-1 mt-10 gap-y-8 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-8">
                <!-- First Name -->
                
      
                <!-- Email Address -->
                <div class="sm:col-span-2">
                  <label for="name"  class="block text-sm font-medium text-gray-900 dark:bg-slate-800 dark:text-white">Username</label>
                  <div class="mt-2">
                    <input type="text" id="email" value="{{  auth()->user()->name }}"   autocomplete="name" class="block w-full rounded-md border border-gray-300 dark:bg-slate-800 dark:text-white py-1.5 px-3 text-gray-900 placeholder-gray-400 shadow-sm focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6">
                  </div>
                  
                </div>
      
              
               
              
               
              </div>
      </div>

      <!-- Personal Information Section -->
      <div class="pb-12 border-b border-gray-300">
        <h2 class="text-2xl font-semibold text-gray-900 dark:bg-slate-800 dark:text-white">Personal Information</h2>
        <p class="mt-1 text-gray-600">Use a permanent address where you can receive mail.</p>

        <div class="grid grid-cols-1 mt-10 gap-y-8 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-8">
          <!-- First Name -->
          

          <!-- Email Address -->
          <div class="sm:col-span-2">
            <label for="email"  class="block text-sm font-medium text-gray-900 dark:bg-slate-800 dark:text-white">Email address</label>
            <div class="mt-2">
              <input type="email" id="email" value="{{  auth()->user()->email }}"   autocomplete="email" class="block w-full rounded-md border border-gray-300 dark:bg-slate-800 dark:text-white py-1.5 px-3 text-gray-900 placeholder-gray-400 shadow-sm focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6">
            </div>
            
          </div>

        
         
        
         
        </div>
      </div> 
      

     

      <!-- Buttons -->
      <div class="flex justify-end mt-6 gap-x-6">
        {{-- <button type="submit" class="text-sm font-semibold text-gray-900">Cancel</button> --}}
       <button disabled wire:navigate   class="px-4 py-2 text-sm font-semibold text-white 
          dark:bg-orange-800 dark:text-white bg-indigo-600 rounded-md shadow-sm 
          hover:bg-indigo-500 focus:ring-2 focus:ring-indigo-600">Ok</button>
      </div>
      {{-- @endforeach --}}
    </form>
  </div>

  <script>
    function previewPhoto(event) {
      const file = event.target.files[0];
      const reader = new FileReader();

      reader.onload = function(e) {
        const img = document.getElementById('photo-preview');
        img.src = e.target.result;
      }

      if (file) {
        reader.readAsDataURL(file);
      }
    }
    function previewPhotos(event) {
      const file = event.target.files[0];
      const reader = new FileReader();

      reader.onload = function(e) {
        const img = document.getElementById('photo-upload');
        img.src = e.target.result;
      }

      if (file) {
        reader.readAsDataURL(file);
      }
    }
  </script>

</body>
</html>
