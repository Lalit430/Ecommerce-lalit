{{-- <div class="relative" wire:click.away="closeMenu">
    <!-- Button -->
    <button wire:click="toggleMenu"
            class="relative flex text-sm bg-gray-800 rounded-full focus:outline-none focus:ring-4 focus:ring-blue-200">
        <img class="rounded-full h-8 w-8 object-cover" 
             src="{{ asset('storage/' . auth()->user()->image) }}" 
             alt="User Image">
    </button>
    
    <!-- Dropdown Menu -->
    @if($open)
        <div class="absolute right-0 z-10 w-48 py-1 mt-2 border-gray-300 border bg-white rounded-md shadow-lg">
            <a wire:navigate href="{{ route('userinfo.show') }}" class="block px-4 py-2 text-gray-700">My Profile</a>
            <a wire:navigate href="/my-orders" class="block px-4 py-2 text-gray-700">My Orders</a>
            <a wire:navigate href="/logout" class="block px-4 py-2 text-gray-700">Sign Out</a>
        </div>
    @endif
</div> --}}
<div class="relative" x-data="{ open: false }">
    <!-- Button -->
    <button @click="open = !open" 
            class="relative flex text-sm bg-gray-800 rounded-full focus:outline-none focus:ring-4 focus:ring-blue-200">
        <img class="rounded-full h-8 w-8 object-cover" 
             src="{{ asset('storage/' . auth()->user()->image) }}" 
             alt="User Image">
    </button>

    <!-- Dropdown Menu -->
    <div x-show="open" 
         @click.away="open = false" 
         x-transition:enter="transition ease-out duration-100"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-75"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="absolute right-0 z-10 w-48 py-1 mt-2 border-gray-300 border bg-white rounded-md shadow-lg">
        
        <a wire:navigate href="{{ route('userinfo.show') }}" class="block px-4 py-2 text-gray-700">My Profile</a>
        <a wire:navigate href="/my-orders" class="block px-4 py-2 text-gray-700">My Orders</a>
        <a wire:navigate href="/logout" class="block px-4 py-2 text-gray-700">Sign Out</a>

        <!-- Display the cart item count -->
        <div class="mt-2 text-sm text-gray-700">
            <p>Items in Cart: {{ $total_count }}</p>
        </div>
    </div>
</div>

