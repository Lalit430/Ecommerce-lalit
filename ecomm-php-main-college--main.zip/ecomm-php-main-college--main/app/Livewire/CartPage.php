<?php
namespace App\Livewire;

use App\Livewire\Partials\Navbar;
use Livewire\Component;
use App\Helpers\CartManagement;
use Livewire\Attributes\Title;

#[Title('Cart-GTechMaria')]
class CartPage extends Component
{
    public $cart_items = [];
    public $sub_total;
    public $shipping_charge;
    public $grand_total;

    public function mount()
    {
        $this->updateCartDetails();
    }

    public function updateCartDetails()
    {
        $this->cart_items = CartManagement::getCartItemsFromCookie();
        $this->sub_total = CartManagement::calculateGrandTotal($this->cart_items);
        $this->shipping_charge = CartManagement::calculateShippingCharge($this->sub_total);
        $this->grand_total = $this->sub_total + $this->shipping_charge;
    }

    public function removeItem($product_id)
    {
        $this->cart_items = CartManagement::removeCartItem($product_id);
        $this->updateCartDetails();
        $this->dispatch('update-cart-count', total_count: count($this->cart_items))->to(Navbar::class);
    }

    public function increaseQty($product_id)
    {
        $this->cart_items = CartManagement::incrementQuantityToCartItem($product_id);
        $this->updateCartDetails();
    }

    public function decreaseQty($product_id)
    {
        $this->cart_items = CartManagement::decrementQuantityToCartItem($product_id);
        $this->updateCartDetails();
    }

    public function render()
    {
        return view('livewire.cart-page', [
            'cart_items' => $this->cart_items,
            'sub_total' => $this->sub_total,
            'shipping_charge' => $this->shipping_charge,
            'grand_total' => $this->grand_total,
        ]);
    }
}







// namespace App\Livewire;
// use App\Livewire\Partials\Navbar;
// use Livewire\Component;


// use App\Helpers\CartManagement;

// use Livewire\Attributes\Title;
// #[Title('Cart-GTechMaria')]
// class CartPage extends Component
// {
//     public $cart_items=[];
//     public $grand_total;

//     public function mount(){
//         $this->cart_items=CartManagement::getCartItemsFromCookie();
//         $this->grand_total=CartManagement::calculateGrandTotal($this->cart_items);
//     }
//     public function removeItem($product_id){
//         $this->cart_items=CartManagement::removeCartItem($product_id);
//         $this->grand_total=CartManagement::calculateGrandTotal($this->cart_items);
//         $this->dispatch('update-cart-count',total_count: count($this->cart_items))->to(Navbar::class);
//     }
//     public function render()
//     {
//         return view('livewire.cart-page');
//     }
//     public function increaseQty($product_id){
//         $this->cart_items=CartManagement::incrementQuantityToCartItem($product_id);
//         $this->grand_total=CartManagement::calculateGrandTotal($this->cart_items);
//       }
//     public function decreaseQty($product_id){
//         $this->cart_items=CartManagement::decrementQuantityToCartItem($product_id);
//         $this->grand_total=CartManagement::calculateGrandTotal($this->cart_items);
//       }
      
// }
