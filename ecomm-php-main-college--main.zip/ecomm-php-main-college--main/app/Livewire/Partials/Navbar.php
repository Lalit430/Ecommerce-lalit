<?php

namespace App\Livewire\Partials;

use Livewire\Component;
use Livewire\Attributes\On;
use App\Helpers\CartManagement;

class Navbar extends Component
{
    public $total_count = 0;
    public $open = false;
    public $menuOpen = false;
    // Event listener to update cart count when emitted
    #[On('update-cart-count')]
    public function mount()
    {
        // Initializes total_count based on the current cart items
        $this->total_count = count(CartManagement::getCartItemsFromCookie());
    }

    // Method to update cart count
    public function updateCartCount($total_count)
    {
        $this->total_count = $total_count;  // Update the property with the new count
    }

    // Method to toggle the menu visibility
    public function toggleMenu()
    {
        $this->open = !$this->open;  // Toggle the open property
    }
    public function toggleMenus()
    {
        $this->menuOpen = !$this->menuOpen;
    }

    // Method to close the menu when clicked away
    public function closeMenu()
    {
        $this->open = false;  // Set open to false to close the dropdown
    }

    public function render()
    {
        // Render the navbar Blade view
        return view('livewire.partials.navbar');
    }
}
