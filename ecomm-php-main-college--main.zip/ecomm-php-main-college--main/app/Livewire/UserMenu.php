<?php

namespace App\Http\Livewire;

use Livewire\Component;

class UserMenu extends Component
{
    public $total_count = 0; // This will accept the value passed from Navbar

    public function render()
    {
        return view('livewire.user-menu');
    }
}
