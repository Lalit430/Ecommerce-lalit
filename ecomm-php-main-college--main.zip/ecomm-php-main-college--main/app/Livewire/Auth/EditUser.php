<?php

namespace App\Livewire\Auth;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Livewire\WithFileUploads;


class EditUser extends Component
{
    use WithFileUploads;


    public $name;


    public $email;

  
    public $password;

  
    public $file;

    public function save(Request $req,$id)
    {


        $user=User::where('id',$id)->first();

        // return view('products.edit',['product'=>$id]);
        

        // Login the user
        auth()->login($user);

        // Redirect to home page
        return redirect()->intended();

    }

    public function render()
    {
        return view('livewire.auth.register-page');
    }
}
