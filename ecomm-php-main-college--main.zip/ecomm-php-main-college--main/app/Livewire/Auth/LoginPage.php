<?php


namespace App\Livewire\Auth;

use Livewire\Component;
use Livewire\Attributes\Title;
use Jantinnerezo\LivewireAlert\LivewireAlert;
#[Title('Login')]
class LoginPage extends Component
{
    use LivewireAlert;
    public $email;
    public $password;

    public function mount()
    {
        if (session()->has('success')) {
            $this->alert('success', session('success'), [
                'position' => 'top-end',
                'timer' => 3000,
                'toast' => true,
            ]);
        }
    }

    public function save()
    {
        // Validate the input
        $this->validate([
            'email' => 'required|email|max:255',
            'password' => 'required|min:6|max:255',
        ]);
    
        // Attempt to authenticate
        if (!auth()->attempt(['email' => $this->email, 'password' => $this->password])) {
            // Flash a single error message to the session
            session()->flash('error', 'Invalid Credentials');
            return;
        }
    
        session()->flash('success', 'Successfully logged in!');
    
        // Emit a Livewire event to navigate client-side
        return redirect()->to('/');
        // $this->dispatchBrowserEvent('navigate', ['url' => '/']);
    }
    

    public function render()
    {
        return view('livewire.auth.login-page');
    }
}


