<?php

namespace App\Livewire\Auth;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Livewire\WithFileUploads;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class RegisterPage extends Component
{
    use WithFileUploads;
    use LivewireAlert;


    public $name;


    public $email;

  
    public $password;

  
    public $file;

    public function save(Request $req)
    {


        
        
        $this->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users|max:255',
            'file' => 'required|mimes:jpeg,jpg,png,gif,webp|max:10000', // Image max size is 1MB
            'password' => 'required|min:6|max:255',
        ]);

        // Store the uploaded file
        $fileName = time() . '_' . $this->file->getClientOriginalName();
        $filePath = $this->file->storeAs('images', $fileName, 'public');

        // Save the user to the database
        $user = User::create([
            'name' => $this->name,
            'email' => $this->email,
            'image' => $filePath,
            'password' => Hash::make($this->password),
        ]);
        

        // Login the user
        auth()->login($user);

        session()->flash('success', 'Successfully Registered!');
        // Redirect to home page
        return redirect()->intended();

    }

    public function render()
    {
        return view('livewire.auth.register-page');
    }
}
