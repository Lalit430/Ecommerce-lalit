<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Livewire\WithFileUploads;

class UserInfo extends Component
{
  use WithFileUploads;

  public $id;

  public $userId;
  public $name;
  public $email;

public $file;

    // Triggered when the file input changes
  
  
    public function edit( $id){

        $this->id=$id;
        $this->name=User::find($id)->name;
        $this->email=User::find($id)->email;
        $this->file=User::find($id)->file;

    }

    public function updateUser()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'email'=> 'email|required',
            'image'=>'nullable|mimes:jpeg,jpg,png,gif,webp|max:10000'
        ]);

        $user = User::findOrFail($this->id);
        $user->update([
            'name' => $this->name,
            'email' => $this->name,
            'file' => $this->file,
        ]);

        session()->flash('success', 'User updated successfully!');
    }

    public function render()
    {
        $user=User::latest()->get();
        return view('livewire.user-info', [
            'userInfo' => $user]);
    }
    
}
//     public function save($id)
//     {
//         Log::info('Save method called with ID: ' . $id); // Log the ID received

//         // Fetch user by ID
//         $this->userInfo = User::findOrFail($id);
//  dd($this->userInfo);
//         // Validate the form fields
//         $this->validate([
//             'name' => 'required|max:255',
//             'email' => 'required|email|unique:users,email,' . $this->userInfo->id . '|max:255',
//             'file' => 'nullable|mimes:jpeg,jpg,png,gif,webp|max:10000',
//             'password' => 'nullable|min:6|max:255',
//         ]);

//         Log::info('Validation passed', ['name' => $this->name, 'email' => $this->email]); // Check if validation passes

//         // Update user info with the new data
//         $this->userInfo->name = $this->name;
//         $this->userInfo->email = $this->email;

//         // Update password if provided
//         if ($this->password) {
//             $this->userInfo->password = bcrypt($this->password);
//         }

//         // Handle file upload if provided
//         if ($this->file) {
//             $fileName = time() . '_' . $this->file->getClientOriginalName();
//             $filePath = $this->file->storeAs('images', $fileName, 'public');
//             Log::info('Uploaded file', ['file' => $fileName]); // Log uploaded file
//             $this->userInfo->image = $filePath;
//         }

//         // Save the user info and catch potential errors
//         try {
//             $this->userInfo->save();
//             Log::info('User info updated');
//         } catch (\Exception $e) {
//             Log::error('Error saving user info', ['error' => $e->getMessage()]);
//         }

//         // Redirect to user info page after successful update
//         return redirect()->route('userinfo.show', $this->userInfo->id);
//     }
