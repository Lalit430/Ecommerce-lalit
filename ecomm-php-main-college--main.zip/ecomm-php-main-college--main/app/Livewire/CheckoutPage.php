<?php

namespace App\Livewire;
use App\Helpers\CartManagement;
use App\Models\Order;
use App\Models\Address;
use Stripe\Stripe;
use Livewire\Attributes\Title;
use Stripe\Checkout\Session;
use Livewire\Component;
use Illuminate\Support\Facades\Mail;
use App\Mail\OrderPlaced;

#[Title('Checkout')]
class CheckoutPage extends Component
{
    public $first_name;
    public $last_name;
    public $phone;
    public $street_address;
    public $city;
    public $state;
    public $zip_code;
    public $payment_method;

    public function mount(){
        $cart_items=CartManagement::getCartItemsFromCookie();
        if(count($cart_items)== 0){
            return redirect('/products');
        }
    }




// {

//     $this->validate([
//         'first_name' => 'required',
//         'last_name' => 'required',
//         'phone' => 'required',
//         'street_address' => 'required',
//         'city' => 'required',
//         'state' => 'required',
//         'zip_code' => 'required',
//         'payment_method' => 'required',
//     ]);


//     $cart_items = CartManagement::getCartItemsFromCookie();
//     $line_items = [];

//     foreach ($cart_items as $item) {
//         $line_items[] = [
//             'price_data' => [
//                 'currency' => 'npr',
//                 'product_data' => [
//                     'name' => $item['name'],
//                 ],
//                 'unit_amount' => $item['unit_amount'] * 100,
//             ],
//             'quantity' => $item['quantity'],
//         ];
//     }


//     $order = new Order();
//     $order->user_id = auth()->user()->id;
//     $order->grand_total = CartManagement::calculateGrandTotal($cart_items);
//     $order->payment_method = $this->payment_method;
//     $order->payment_status = 'pending';
//     $order->status = 'new';
//     $order->currency = 'npr';
//     $order->shipping_amount = 0;
//     $order->shipping_method = 'none';
//     $order->notes = 'Order Placed by ' . auth()->user()->name;


//     $address = new Address();
//     $address->first_name = $this->first_name;
//     $address->last_name = $this->last_name;
//     $address->phone = $this->phone;
//     $address->street_address = $this->street_address;
//     $address->city = $this->city;
//     $address->state = $this->state;
//     $address->zip_code = $this->zip_code;

//     $redirect_url = '';


//     if ($this->payment_method == 'stripe') {
//         Stripe::setApiKey(env('STRIPE_SECRET'));

//         try {
//             $sessionCheckout = \Stripe\Checkout\Session::create([
//                 'payment_method_types' => ['card'],
//                 'customer_email' => auth()->user()->email,
//                 'line_items' => $line_items,
//                 'mode' => 'payment', // Use 'subscription' if it's for subscriptions
//                 'success_url' => route('success') .'?session_id={CHECKOUT_SESSION_ID}',
//                 'cancel_url' => route('cancel'),
//             ]);

//             $redirect_url = $sessionCheckout->url;
//         } catch (\Exception $e) {

//             return response()->json(['error' => $e->getMessage()], 500);
//         }
//     } else {
//         $redirect_url = route('success');
//     }


//     $order->save();
//     $address->order_id = $order->id;
//     $address->save();


   
//     $order->items()->createMany($cart_items);
//     CartManagement::clearCartItems();
//     Mail::to(request()->user())->send(new OrderPlaced($order));


//     return redirect($redirect_url);


  
// }

public function placeOrder()
{
    $this->validate([
        'first_name' => 'required',
        'last_name' => 'required',
        'phone' => 'required',
        'street_address' => 'required',
        'city' => 'required',
        'state' => 'required',
        'zip_code' => 'required',
        'payment_method' => 'required',
    ]);

    // 🛒 Get cart items from cookie
    $cart_items = CartManagement::getCartItemsFromCookie();

    // ✅ Ensure valid product_id exists before inserting
    $cart_items = collect($cart_items)->map(function ($item) {
        return [
            'product_id' => $item['product_id'] ?? null,
            'name' => $item['name'], // Include product name for Stripe
            'quantity' => $item['quantity'],
            'unit_amount' => (float) $item['unit_amount'], // Ensure it's a float
        ];
    })->filter(fn($item) => \App\Models\Product::where('id', $item['product_id'])->exists())
    ->toArray();

    if (empty($cart_items)) {
        return redirect('/cart')->withErrors('Some products are no longer available.');
    }

    // 💰 Calculate grand total
    $sub_total = collect($cart_items)->sum(fn($item) => $item['unit_amount'] * $item['quantity']);

    // 🚚 Calculate shipping charge
    $shipping_amount = CartManagement::calculateShippingCharge($sub_total);

    // 📦 Create Order
    $order = new Order();
    $order->user_id = auth()->user()->id;
    $order->grand_total = $sub_total + $shipping_amount; // Include shipping charge
    $order->payment_method = $this->payment_method;
    $order->payment_status = 'pending';
    $order->status = 'new';
    $order->currency = 'npr';
    $order->shipping_amount = $shipping_amount;
    $order->shipping_method = 'standard'; // Can add different methods later
    $order->notes = 'Order Placed by ' . auth()->user()->name;
    $order->save();

    // 📍 Save Address
    $address = new Address();
    $address->order_id = $order->id;
    $address->first_name = $this->first_name;
    $address->last_name = $this->last_name;
    $address->phone = $this->phone;
    $address->street_address = $this->street_address;
    $address->city = $this->city;
    $address->state = $this->state;
    $address->zip_code = $this->zip_code;
    $address->save();

    // 🛒 Insert order items
    $order_items = collect($cart_items)->map(fn($item) => [
        'product_id' => $item['product_id'],
        'quantity' => $item['quantity'],
        'unit_amount' => $item['unit_amount'],
    ])->toArray();
    $order->items()->createMany($order_items);

    // 💳 Handle Stripe Checkout
    if ($this->payment_method == 'stripe') {
        Stripe::setApiKey(env('STRIPE_SECRET'));

        // Prepare Stripe line items
        $line_items = collect($cart_items)->map(fn($item) => [
            'price_data' => [
                'currency' => 'npr',
                'product_data' => [
                    'name' => $item['name'],
                ],
                'unit_amount' => intval($item['unit_amount'] * 100), // Convert to cents
            ],
            'quantity' => $item['quantity'],
        ])->toArray();

        // Add shipping charge to Stripe
        $line_items[] = [
            'price_data' => [
                'currency' => 'npr',
                'product_data' => ['name' => 'Shipping Fee'],
                'unit_amount' => intval($shipping_amount * 100),
            ],
            'quantity' => 1,
        ];

        try {
            $sessionCheckout = Session::create([
                'payment_method_types' => ['card'],
                'customer_email' => auth()->user()->email,
                'line_items' => $line_items,
                'mode' => 'payment',
                'success_url' => route('success') . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('cancel'),
            ]);

            $redirect_url = $sessionCheckout->url;
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    } else {
        $redirect_url = route('success');
    }

    // 🛒 Clear cart & send email
    CartManagement::clearCartItems();
    Mail::to(request()->user())->send(new OrderPlaced($order));

    return redirect($redirect_url);
}



public function render()
{
    $cart_items = CartManagement::getCartItemsFromCookie();
    $sub_total = collect($cart_items)->sum(fn($item) => $item['unit_amount'] * $item['quantity']);
    $shipping_amount = CartManagement::calculateShippingCharge($sub_total);
    $grand_total = $sub_total + $shipping_amount;

    return view('livewire.checkout-page', [
        'cart_items' => $cart_items,
        'sub_total' => $sub_total,
        'shipping_amount' => $shipping_amount,
        'grand_total' => $grand_total,
    ]);
}

}

