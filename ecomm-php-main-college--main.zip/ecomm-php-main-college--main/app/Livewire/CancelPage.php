<?php

namespace App\Livewire;

use Livewire\Component;

class CancelPage extends Component
{
    public function render()
    {
        return view('livewire.cancel-page');
    }
}
