<?php

namespace App\Livewire;
// use App\Models\Product;
use App\Livewire\Partials\Navbar;
use App\Helpers\CartManagement;
use App\Mail\contact\ContactUsMail;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;

use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Attributes\Title;

#[Title('About Us - GTechMaria')]
class AboutPage extends Component
{
//   use LivewireAlert;
//     public $slug;
//     public $quantity=1;
//     public function mount($slug){
//       $this->slug=$slug;
//     }
//     public function increaseQty(){
//       $this->quantity++;
//     }
//     public function decreaseQty(){
//       if($this->quantity>1){
//         $this->quantity--;
//       }

//     }

//     public function addToCart($product_id){

//       $total_count=CartManagement::addItemToCartWithQty($product_id,$this->quantity);

//       $this->dispatch('update-cart-count',total_count: $total_count)->to(Navbar::class);

//       $this->alert('success', 'Product added to cart', [
//           'position' => 'bottom-end',
//           'timer' => 3000,
//           'toast' => true,
//          ]);

//   }
public $name;
public $email;
public $message;

protected $rules=[
'name'=>'required|string|min:3|max:255',
'email'=>'required|email|min:3|max:255',
'message'=>'required|string|min:3|max:1000'
];
    public function render()
    {
        return view('livewire.about-page',
        // ['product'=>Product::where('slug',$this->slug)->firstOrFail(),]
        );
    }
    public function updated($propertyName){
         $this->validateOnly(($propertyName));
    }
    public function send(){
        $validateData=$this->validate();

        //Send Email
        try {
            Mail::to('support@gtechmaria.com')->send(New ContactUsMail($validateData));
            Session()->flash('success','Message sent successfully!');
        } catch (\Throwable $th) {
            Session()->flash('error','Failed to send message. Please try again later!');
        }
        

        $this->reset();
    }
}

