<?php
use App\Livewire\HomePage;
use App\Livewire\CategoriesPage;
use App\Livewire\ProductsPage;
use App\Livewire\ProductDetailPage;
use App\Livewire\CartPage;
use App\Livewire\SuccessPage;
use App\Livewire\CancelPage;

use App\Livewire\CheckoutPage;
use App\Livewire\MyOrdersPage;
use App\Livewire\MyOrderDetailPage;
use App\Livewire\Auth\LoginPage;
use App\Livewire\Auth\RegisterPage;
use App\Livewire\Auth\ForgotPasswordPage;
use App\Livewire\Auth\ResetPasswordPage;
use App\Http\Controllers\ImageController;
use App\Http\Livewire\UserUpdate as LivewireUserUpdate;
use App\Livewire\AboutPage;
use App\Livewire\Auth\EditUser;
use App\Livewire\UserInfoPage;
use Illuminate\Support\Facades\Route;
use App\Livewire\Auth\UploadController;
use App\Livewire\UserInfo;

use App\Http\Livewire\UserUpdate;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', HomePage::class );
Route::get('/about', AboutPage::class );
Route::get('/user', UserInfo::class)->name('userinfo.show');
// Route::get('/user-update', UserUpdate::class)->name('user.update');
// Route::put('/user/{id}/update', UserInfoPage::class)->name('userinfo.update');

 // To display the form for a specific user, e.g., edit page



Route::get('/home', HomePage::class );
Route::get('/categories', CategoriesPage::class );
Route::get('/products', ProductsPage::class);
Route::get('/cart', CartPage::class);
Route::get('/products/{slug}', ProductDetailPage::class);





Route::middleware('guest')->group(function(){
    Route::get('/login',LoginPage::class)->name('login');
    // Route::resource('/register', UploadController::class);
    Route::get('/register',RegisterPage::class);
    
    // Route::post('/register',RegisterPage::class);
    // Route::get('/register', UploadController::class);
    // Route::post('/register', UploadController::class);
    // Route::resource('/register',RegisterPage::class);
    Route::get('/forgot',ForgotPasswordPage::class)->name('password.request');
    Route::get('/reset/{token}',ResetPasswordPage::class)->name('password.reset');

});


Route::middleware('auth')->group(function(){
    Route::get('/logout',function(){
        auth()->logout();
        return redirect('/');
    }
   
);

    Route::get('/checkout', CheckoutPage::class);
    Route::get('/my-orders', MyOrdersPage::class);
    Route::get('/my-orders/{order_id}', MyOrderDetailPage::class)->name('my-orders.show');
    Route::get('/success',SuccessPage::class)->name('success');
Route::get('/cancel',CancelPage::class)->name('cancel');

});


// routes/web.php






// Route::middleware('auth')->group(function(){
//     Route::get('/logout', function(){
//         auth()->logout();
//         return redirect('/');
//     });
//     Route::get('/checkout', CheckoutPage::class);
//     Route::get('/my-orders', MyOrdersPage::class);
//     Route::get('/my-orders/{order}', MyOrderDetailPage::class);
//     Route::get('/success', SuccessPage::class);
//     Route::get('/cancel', CancelPage::class);
// });
